# NOW_ NO OFFICE WORK

Website created using [Bootstrap](http://getbootstrap.com/). Started with the theme [Stylish Portfolio](http://startbootstrap.com/template-overviews/stylish-portfolio/), created by [Start Bootstrap](http://startbootstrap.com/), but I've since modified it to fit NOWs needs.

## Copyright and License

Website - Copyright 2013-2018 Manuel Palmeira
Theme - Copyright 2013-2018 Blackrock Digital LLC. Code released under the [MIT](https://github.com/BlackrockDigital/startbootstrap-stylish-portfolio/blob/gh-pages/LICENSE) license.
